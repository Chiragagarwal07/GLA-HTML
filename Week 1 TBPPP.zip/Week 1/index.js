function details(){
    document.getElementById("card").setAttribute('style','display:flex');
}
function close(){
    document.getElementById("card").style.display = "none";
}